package com.test;

public interface Robot {

    public void setNama(String nama);

    public void setTahunPembuatan(int tahun);

    public void displayData();
}
