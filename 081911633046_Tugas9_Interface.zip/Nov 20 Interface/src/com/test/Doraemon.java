package com.test;

public interface Doraemon {

    public void sayDora();

    public void displayKantongAjaib();
}
