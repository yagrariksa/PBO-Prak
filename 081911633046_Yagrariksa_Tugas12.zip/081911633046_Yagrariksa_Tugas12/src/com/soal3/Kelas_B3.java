package com.soal3;

public interface Kelas_B3 {
    public int hitungKurang(int a,int b);
}
