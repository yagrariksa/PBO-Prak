package com.soal3;

public interface Kelas_C3 extends Kelas_A3, Kelas_B3 {

    public int hitungJumlah(int a,int b);
}
