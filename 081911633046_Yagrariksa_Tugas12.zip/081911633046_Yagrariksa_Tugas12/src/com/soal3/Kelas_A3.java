package com.soal3;

public interface Kelas_A3 {
    public int hitungKali(int a,int b);
}
