package com.main;

public interface Kelas_A1 {
    public int hitungKali(int a, int b);
}
