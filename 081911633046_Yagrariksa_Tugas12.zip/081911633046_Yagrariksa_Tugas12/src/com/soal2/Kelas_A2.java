package com.soal2;

public interface Kelas_A2 {
    public int hitungKali(int a, int b);
}
