package com.soal2;

public class Kelas_B2 {

    public static final int NILAI_B = 60;

    public int b;

    public Kelas_B2(int b) {
        this.b = b;
    }

    public int getB() {
        return b;
    }

    public int hitungKurang(int a, int b){
        return (a-b);
    }


}
